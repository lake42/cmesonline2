<?php
/*******************************
* Name : Simple ImageShack
* Version : 3.1.3
*******************************/

// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');


// Add mod setting to the database	
global $modSettings;

if(!isset($modSettings['sis_enable']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_enable", "1")',
      array()
   );


if(!isset($modSettings['sis_cookie']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_cookie", "Your ImageShack Registration Code")',
      array()
   );

if(!isset($modSettings['sis_permis']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_permis", "0")',
      array()
   );

if(!isset($modSettings['sis_addops']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_addops", "1")',
      array()
   );

if(!isset($modSettings['sis_forumtag']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_forumtag", "1")',
      array()
   );

if(!isset($modSettings['sis_tags']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_tags", "SIS313,www.SimpleTweaks.info")',
      array()
   );

if(!isset($modSettings['sis_imagelink']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_imagelink", "1")',
      array()
   );

if(!isset($modSettings['sis_imagelink_bbcode']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_imagelink_bbcode", "1")',
      array()
   );

if(!isset($modSettings['sis_thumblink_bbcode']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_thumblink_bbcode", "1")',
      array()
   );

if(!isset($modSettings['sis_thumblink_click']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_thumblink_click", "1")',
      array()
   );

if(!isset($modSettings['sis_rembar']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_rembar", "0")',
      array()
   );

if(!isset($modSettings['sis_width']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_width", "660")',
      array()
   );

if(!isset($modSettings['sis_height']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_height", "240")',
      array()
   );

if(!isset($modSettings['sis_color']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_color", "7A7A7A")',
      array()
   );

if(!isset($modSettings['sis_loader']))
   $smcFunc['db_query']('', '
      INSERT INTO {db_prefix}settings
      VALUES ("sis_loader", "2")',
      array()
   );

?>