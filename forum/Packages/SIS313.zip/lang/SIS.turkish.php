<?php
/***************************************************************************
 *			      SIS.turkish.php
 *	               ---------------------
 *	Version	: 3.1.0
 *	Support	: http://simpletweaks.info
 *
 *				&copy;2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack"

// SISform
$SISiframe_txt2 = "k�t� dosya tipi";
$SISiframe_txt3 = "g�nder!";
$SISiframe_txt4 = "dosya y�kle - y�kleme uzun s�rebilir";
$SISiframe_txt5 = "izin verilenler: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "L�tfen desteklenen dosya tiplerinden birini se�in.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "yeniden boyutlandir?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (�nizleme)";
$SISiframe_txt11 = "320x240 (websiteleri ve email i�in)";
$SISiframe_txt12 = "640x480 (mesaj panolari i�in)";
$SISiframe_txt13 = "800x600 (15-in� monitor)";
$SISiframe_txt14 = "1024x768 (17-in� monitor)";
$SISiframe_txt15 = "1280x1024 (19-in� monitor)";
$SISiframe_txt16 = "1600x1200 (21-in� monitor)";
$SISiframe_txt17 = "boyutlandirma olmadan optimize";
$SISiframe_txt18 = "�nizlemeden boyut/��z�n�rl�k �ubugunu kaldir?";
// help
$SISiframe_txt30 = "yardim";
$SISiframe_txt31 = "Simple ImageShack Nasil Kullanilir";
$SISiframe_txt32 = "
   -<i>G�zat</i> butonuna tikla ve sabitdiskinden bir resim se�.<br /><br />
   -<i>$SISiframe_txt3</i> butonuna tikla ve resim y�klemesi bitene kadar bekle.<br /><br />
   -Resim basariyla y�klendiginde resim ve/veya �nizleme karsina �ikacak.<br /><br />
   -Kodlardan birini kopyala ve resmin g�z�kmesini istedigin yere yapistir.<br /><br />
   -Eger bir resim daha g�ndermek istiyorsan <img src='./img/image_add.png' alt='' /> butonuna tikla.
         ";

// SISxmlapi
$SISiframe_txt40 = "Eyvah, bir seyler yanlis gitti";
$SISiframe_txt41 = "XML d�n�s� basarisiz";
$SISiframe_txt42 = "Tekrar denemek i�in tiklayin";
$SISiframe_txt43 = "��z�n�rl�k";
$SISiframe_txt44 = "Y�kleme basarili!";
$SISiframe_txt45 = "Resim Linki";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode Resim";
$SISiframe_txt48 = "BBcode �nizleme";
$SISiframe_txt49 = "Tiklanabilir �nizleme";
$SISiframe_txt50 = "baska resim yolla";
$SISiframe_txt51 = "resim yolu ayarlanmadi";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>
