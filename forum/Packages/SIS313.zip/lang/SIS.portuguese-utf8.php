<?php
/***************************************************************************
 *			      SIS.portuguese-utf8.php
 *	               -------------------
 *	Version: 3.0.3
 *	Support: http://simpletweaks.info
 *  Translation: FragaCampos 
 *
 *	                  ©2010 Simple Tweaks
 **************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "Tipo de ficheiro errado";
$SISiframe_txt3 = "Enviar!";
$SISiframe_txt4 = "A enviar ficheiro - aguarde por favor";
$SISiframe_txt5 = "Extensões permitidas: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "Por favor, seleccione apenas um dos tipos de ficheiros suportados.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "Redimensionar imagem?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (thumbnail)";
$SISiframe_txt11 = "320x240 (para websites e email)";
$SISiframe_txt12 = "640x480 (para fóruns)";
$SISiframe_txt13 = "800x600 (monitor de 15'')";
$SISiframe_txt14 = "1024x768 (monitor de 17'')";
$SISiframe_txt15 = "1280x1024 (monitor de 19'')";
$SISiframe_txt16 = "1600x1200 (monitor de 21'')";
$SISiframe_txt17 = "Optimizar sem redimensionar";
$SISiframe_txt18 = "Remover a barra de tamanho/resolução do thumbnail?";
// help
$SISiframe_txt30 = "Ajuda";
$SISiframe_txt31 = "Como usar o Simple ImageShack";
$SISiframe_txt32 = "
	-Clique em <i>Procurar</i> e escolha a imagem do seu disco rígido.<br />
	-Clique em <i>$SISiframe_txt3</i> e aguarde até que a imagem tenha sido enviada.<br />
	-Quando a imagem tiver sido enviada com sucesso ser-lhe-á mostrada a imagem ou thumbnail.<br />
	-Copie e cole um dos códigos mostrados junto à imagem.<br />
	-Clique em <img src='./img/image_add.png' alt='' /> se quiser hospedar outra imagem.
			";

// SISxmlapi
$SISiframe_txt40 = "Oops, houve algo que correu mal...";
$SISiframe_txt41 = "Falha no ficheiro XML";
$SISiframe_txt42 = "Clique aqui para tentar novamente";

$SISiframe_txt43 = "Resolução";
$SISiframe_txt44 = "Envio bem-sucedido!";
$SISiframe_txt45 = "Link da imagem";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode Image";
$SISiframe_txt48 = "BBcode Thumb";
$SISiframe_txt49 = "Thumb clicável";
$SISiframe_txt50 = "Hospedar outra imagem";
$SISiframe_txt51 = "image path not set";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>