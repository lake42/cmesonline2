<?php
/***************************************************************************
 *			      SIS.french-utf8.php
 *	           ---------------------
 *	Version	: 3.0.3
 *	Support	: http://simpletweaks.info
 *  Translation: vroum 
 *
 *				©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "Type de fichier incorrect";
$SISiframe_txt3 = "envoyer!";  //means send because it's easier to understand than /l'héberger/ for host it
$SISiframe_txt4 = "envoi de fichier - patience pendant le téléchargement";  //sending... here's why the previous was more
                                                                            //meaningful
$SISiframe_txt5 = "acceptés: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "S'il vous plaît choisissez seulement des types de fichiers pris en charge.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "resize image?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (thumbnail)";
$SISiframe_txt11 = "320x240 (pour les sites web et e-mail)";
$SISiframe_txt12 = "640x480 (pour les message boards)";
$SISiframe_txt13 = "800x600 (moniteur de 15 pouces)";
$SISiframe_txt14 = "1024x768 (moniteur de 17 pouces)";
$SISiframe_txt15 = "1280x1024 (moniteur de 19 pouces)";
$SISiframe_txt16 = "1600x1200 (moniteur de 21 pouces)";
$SISiframe_txt17 = "optimiser sans redimensionnement";
$SISiframe_txt18 = "Retirer la barre de taille/résolution du thumbnail?";
// help
$SISiframe_txt30 = "Aide";
$SISiframe_txt31 = "Comment utiliser Simple ImageShack";
$SISiframe_txt32 = "
	-Cliquez <i>Parcourir</ i>et sélectionnez l'image à partir de votre disque dur.<br />
	-Cliquez <i>$SISiframe_txt3</ i> et attendez que l'image a été téléchargée.<br />
	-Lorsque l'image a été transférée avec succès l'image ou le thumbnail téléchargé sera affiché.<br />
	-Copier et coller un des codes affichés à côté de l'image. <br /> <br />
	-Cliquez <img src='image_add.png' alt='' /> Si vous souhaitez héberger une autre image.
			";

// SISxmlapi
$SISiframe_txt40 = "Attention, quelque chose s'est mal passé";
$SISiframe_txt41 = "retour XML échoué";
$SISiframe_txt42 = "Cliquez ici pour essayer à nouveau";

$SISiframe_txt43 = "Résolution";
$SISiframe_txt44 = "Envoi réussie!";
$SISiframe_txt45 = "Lien vers l'image";
$SISiframe_txt46 = "BBcode (pour afficher l'image à l'intérieur du message)"; //(to display the image inside the message)
$SISiframe_txt47 = "BBcode Image";
$SISiframe_txt48 = "BBcode Thumbnail";
$SISiframe_txt49 = "Thumbnail Clickable";
$SISiframe_txt50 = "héberger une autre image";
$SISiframe_txt51 = "image path not set";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>