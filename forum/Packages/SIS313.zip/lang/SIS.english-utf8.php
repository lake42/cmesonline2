<?php
/***************************************************************************
 *			      SIS.english-utf8.php
 *	               --------------------- 
 *	Version	: 3.1.0
 *	Support	: http://simpletweaks.co.nr
 *
 *      Simple Tweaks in Greek: Τσιμπήματα Απλή
 *              ©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "bad file type";
$SISiframe_txt3 = "host it!";
$SISiframe_txt4 = "upload file - patience during upload";
$SISiframe_txt5 = "allowed: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "Please select only one of the supported file types.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "resize image?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (thumbnail)";
$SISiframe_txt11 = "320x240 (for websites and email)";
$SISiframe_txt12 = "640x480 (for message boards)";
$SISiframe_txt13 = "800x600 (15-inch monitor)";
$SISiframe_txt14 = "1024x768 (17-inch monitor)";
$SISiframe_txt15 = "1280x1024 (19-inch monitor)";
$SISiframe_txt16 = "1600x1200 (21-inch monitor)";
$SISiframe_txt17 = "optimize without resizing";
$SISiframe_txt18 = "remove size/resolution bar from thumbnail?";
// help
$SISiframe_txt30 = "help";
$SISiframe_txt31 = "How to use Simple ImageShack";
$SISiframe_txt32 = "
	-Click <i>Browse</i> and select image from your Hard-Drive.<br />
	-Click <i>$SISiframe_txt3</i> and wait untill the image has been uploaded.<br />
	-When the image has been uploaded succesfully the uploaded image or thumbnail will show.<br />
	-Copy and Paste one of the codes displayed next to the image.<br />
	-Click <img src='./img/image_add.png' alt='' /> if you want to host another image.
			";

// SISxmlapi
$SISiframe_txt40 = "Oops, something went wrong";
$SISiframe_txt41 = "XML return failed";
$SISiframe_txt42 = "Click here to try again";

$SISiframe_txt43 = "Resolution";
$SISiframe_txt44 = "Upload successful!";
$SISiframe_txt45 = "Image Link";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode Image";
$SISiframe_txt48 = "BBcode Thumb";
$SISiframe_txt49 = "Clickable Thumb";
$SISiframe_txt50 = "host another image";
$SISiframe_txt51 = "image path not set";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>
