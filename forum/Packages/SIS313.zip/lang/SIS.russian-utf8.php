<?php
/***************************************************************************
 *			      SIS.russian-utf8.php
 *	               ---------------------
 *	Version	: 3.0.3
 *	Support	: http://simpletweaks.info
 *	Translation: virtualband.ru 
 *
 *				©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "неподдерживаемый тип файла";
$SISiframe_txt3 = "загрузить!";
$SISiframe_txt4 = "дождитесь завершения загрузки";
$SISiframe_txt5 = "типы файлов: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "Выберите поддерживаемый тип файла.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "изменить размер?";
$SISiframe_txt9 = "100x75 (аватар)";
$SISiframe_txt10 = "150x112 (миниатюра)";
$SISiframe_txt11 = "320x240 (для писем и вебсайтов)";
$SISiframe_txt12 = "640x480 (для досок объявления)";
$SISiframe_txt13 = "800x600 (15 дюймов)";
$SISiframe_txt14 = "1024x768 (17 дюймов)";
$SISiframe_txt15 = "1280x1024 (19 дюймов)";
$SISiframe_txt16 = "1600x1200 (21 дюйм)";
$SISiframe_txt17 = "оптимизировать, не меняя разрешение";
$SISiframe_txt18 = "не отображать разрешение в миниатюре?";
// help
$SISiframe_txt30 = "помощь";
$SISiframe_txt31 = "Справка по ImageShack";
$SISiframe_txt32 = "
	-Нажмите <i>Обзор</i> и выберите изображение на жестком диске.<br />
	-Нажмите <i>$SISiframe_txt3</i> и дождитесь окончания загрузки.<br />
	-После успешного завершения загрузки вы увидите миниатюру изображения.<br />
	-Скопируйте одну из ссылок в форму ответа.<br />
	Для повторной загрузки нажмите <img src='image_add.png' alt='' />.
			";

// SISxmlapi
$SISiframe_txt40 = "Произошла ошибка";
$SISiframe_txt41 = "Данные XML не были получены";
$SISiframe_txt42 = "Попробовать снова";

$SISiframe_txt43 = "Разрешение";
$SISiframe_txt44 = "Загрузка завершена!";
$SISiframe_txt45 = "Прямая ссылка";
$SISiframe_txt46 = "Для форума";
$SISiframe_txt47 = "Для форума (полный размер)";
$SISiframe_txt48 = "Для форума (миниатюра)";
$SISiframe_txt49 = "Для форума (миниатюра с переходом)";
$SISiframe_txt50 = "Загрузить еще";
$SISiframe_txt51 = "image path not set";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='SISfrog.png' alt='' />";

?>