<?php
/***************************************************************************
 *               SIS.greek-utf8.php
 *            ---------------------
 *    Version     : 3.0.3
 *    Support     : http://simpletweaks.info
 *    Translate   : nikan
 * 
 *               copyright 2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "Λάθος τύπος αρχείου";
$SISiframe_txt3 = "Αποστολή!";
$SISiframe_txt4 = "Αποστολή αρχείου - Υπομονή κατά την αποστολή";
$SISiframe_txt5 = "Επιτρέπονται: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "Παρακαλώ επιλέξτε μόνο υποστηριζόμενους τύπους αρχείων.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "Αλλαγή διαστάσεων εικόνας;";
$SISiframe_txt9 = "100x75 (πορτραίτο)";
$SISiframe_txt10 = "150x112 (μικρογραφία)";
$SISiframe_txt11 = "320x240 (για ιστοσελίδες και email)";
$SISiframe_txt12 = "640x480 (για φόρουμ)";
$SISiframe_txt13 = "800x600 (οθόνη 15-ιντσών)";
$SISiframe_txt14 = "1024x768 (οθόνη 17-ιντσών)";
$SISiframe_txt15 = "1280x1024 (οθόνη 19-ιντσών)";
$SISiframe_txt16 = "1600x1200 (οθόνη 21-ιντσών)";
$SISiframe_txt17 = "Βελτιστοποίηση χωρίς αλλαγή διαστάσεων";
$SISiframe_txt18 = "Αφαίρεση γραμμής πληροφοριών μεγέθους/ανάλυσης από την μικρογραφία;";
// help
$SISiframe_txt30 = "Βοήθεια";
$SISiframe_txt31 = "Πως θα χρησιμοποιήσω το Simple ImageShack";
$SISiframe_txt32 = "
	-Κάντε κλικ στο <i>Browse</i> και επιλέξτε εικόνα από το σκληρό δίσκο σας.<br />
	-Κάντε κλικ στο <i>$SISiframe_txt3</i> και περιμένετε μέχρι να αποσταλεί η εικόνα.<br />
	-Όταν αποσταλεί επιτυχώς η εικόνα θα εμφανιστεί η εικόνα ή μια μικρογραφία.<br />
	-Αντιγράψτε και επικολλήστε έναν από τους κώδικες που εμφανίζονται δίπλα στην εικόνα.<br />
	-Κάντε κλικ στο <img src='./img/image_add.png' alt='' /> αν θέλετε να αποστείλετε άλλη εικόνα.
			";

// SISxmlapi
$SISiframe_txt40 = "Ωπ, συνέβη ένα λάθος";
$SISiframe_txt41 = "Η επιστροφή XML απέτυχε";
$SISiframe_txt42 = "Κάντε κλικ εδώ για να ξαναπροσπαθήσετε";

$SISiframe_txt43 = "Ανάλυση";
$SISiframe_txt44 = "Επιτυχής αποστολή!";
$SISiframe_txt45 = "Σύνδεσμος εικόνας";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode εικόνας";
$SISiframe_txt48 = "BBcode μικρογραφίας";
$SISiframe_txt49 = "Μικρογραφία με σύνδεσμο";
$SISiframe_txt50 = "Αποστολή άλλης εικόνας";
$SISiframe_txt51 = "image path not set";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>