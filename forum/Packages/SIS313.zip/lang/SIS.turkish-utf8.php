<?php
/***************************************************************************
 *			      SIS.turkish-utf8.php
 *	               --------------------- 
 *	Version	: 3.1.0
 *	Support	: http://simpletweaks.co.nr
 *
 *      Simple Tweaks in Greek: Τσιμπήματα Απλή
 *              ©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack"

// SISform
$SISiframe_txt2 = "kÃ¶tÃ¼ dosya tipi";
$SISiframe_txt3 = "gÃ¶nder!";
$SISiframe_txt4 = "dosya yÃ¼kle - yÃ¼kleme uzun sÃ¼rebilir";
$SISiframe_txt5 = "izin verilenler: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "LÃ¼tfen desteklenen dosya tiplerinden birini seÃ§in.";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "yeniden boyutlandÄ±r?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (Ã¶nizleme)";
$SISiframe_txt11 = "320x240 (websiteleri ve email iÃ§in)";
$SISiframe_txt12 = "640x480 (mesaj panolarÄ± iÃ§in)";
$SISiframe_txt13 = "800x600 (15-inÃ§ monitor)";
$SISiframe_txt14 = "1024x768 (17-inÃ§ monitor)";
$SISiframe_txt15 = "1280x1024 (19-inÃ§ monitor)";
$SISiframe_txt16 = "1600x1200 (21-inÃ§ monitor)";
$SISiframe_txt17 = "boyutlandÄ±rma olmadan optimize";
$SISiframe_txt18 = "Ã¶nizlemeden boyut/Ã§Ã¶zÃ¼nÃ¼rlÃ¼k Ã§ubuÄŸunu kaldÄ±r?";

// help
$SISiframe_txt30 = "yardÄ±m";
$SISiframe_txt31 = "Simple ImageShack NasÄ±l KullanÄ±lÄ±r";
$SISiframe_txt32 = "
   -<i>GÃ¶zat</i> butonuna tÄ±kla ve sabitdiskinden bir resim seÃ§.<br /><br />
   -<i>$SISiframe_txt3</i> butonuna tÄ±kla ve resim yÃ¼klemesi bitene kadar bekle.<br /><br />
   -Resim baÅŸarÄ±yla yÃ¼klendiÄŸinde resim ve/veya Ã¶nizleme karÅŸÄ±na Ã§Ä±kacak.<br /><br />
   -Kodlardan birini kopyala ve resmin gÃ¶zÃ¼kmesini istediÄŸin yere yapÄ±ÅŸtÄ±r.<br /><br />
   -EÄŸer bir resim daha gÃ¶ndermek istiyorsan <img src='./img/image_add.png' alt='' /> butonuna tÄ±kla.
         ";

// SISxmlapi
$SISiframe_txt40 = "Eyvah, bir ÅŸeyler yanlÄ±ÅŸ gitti";
$SISiframe_txt41 = "XML dÃ¶nÃ¼ÅŸÃ¼ baÅŸarÄ±sÄ±z";
$SISiframe_txt42 = "Tekrar denemek iÃ§in tÄ±klayÄ±n";
$SISiframe_txt43 = "Ã‡Ã¶zÃ¼nÃ¼rlÃ¼k";
$SISiframe_txt44 = "YÃ¼kleme baÅŸarÄ±lÄ±!";
$SISiframe_txt45 = "Resim Linki";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode Resim";
$SISiframe_txt48 = "BBcode Ã–nizleme";
$SISiframe_txt49 = "TÄ±klanabilir Ã–nizleme";
$SISiframe_txt50 = "baÅŸka resim yolla";
$SISiframe_txt51 = "resim yolu ayarlanmadÄ±";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>
