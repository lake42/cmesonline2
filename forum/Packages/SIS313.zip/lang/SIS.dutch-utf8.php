<?php
/***************************************************************************
 *			      SIS.dutch-utf8.php
 *	               -------------------
 *	Version  : 3.0.3
 *	Support  : http://simpletweaks.info
 *
 *	                  ©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "Simple ImageShack";

// SISform
$SISiframe_txt2 = "Foute bestand type";
$SISiframe_txt3 = "host it!";
$SISiframe_txt4 = "upload bestand - geduld tijdens upload";
$SISiframe_txt5 = "toegestaan: jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "Selecteer alleen een van de ondersteunde bestand types.";
$SISiframe_txt7 = "";
$SISiframe_txt8 = "Wijzig formaat afbeelding?";
$SISiframe_txt9 = "100x75 (avatar)";
$SISiframe_txt10 = "150x112 (thumbnail)";
$SISiframe_txt11 = "320x240 (voor websites en email)";
$SISiframe_txt12 = "640x480 (voor message boards)";
$SISiframe_txt13 = "800x600 (15-inch monitor)";
$SISiframe_txt14 = "1024x768 (17-inch monitor)";
$SISiframe_txt15 = "1280x1024 (19-inch monitor)";
$SISiframe_txt16 = "1600x1200 (21-inch monitor)";
$SISiframe_txt17 = "optimaliseer zonder resizing";
$SISiframe_txt18 = "verwijder size/resolution bar van thumbnail?";
// help
$SISiframe_txt30 = "help";
$SISiframe_txt31 = "Hoe gebruik je Simple ImageShack";
$SISiframe_txt32 = "
	-Klik op <i>Bladeren</i> en selecteert een afbeelding van je Hard-Drive.<br />
	-Klik op <i>$SISiframe_txt3</i> en wacht tot de afbeelding is ge-upload.<br />
	-Wanneer de afbeelding succesvol is ge-upload wordt de afbeelding of thumbnail afgebeeld.<br />
	-Kopieer en Plak (Copy and Paste) een van de codes.<br />
	-Klik op <img src='./img/image_add.png' alt='' /> om nog een afbeelding te uploaden.
			";

// SISxmlapi
$SISiframe_txt40 = "Oeps, er ging iets verkeerd";
$SISiframe_txt41 = "XML return failed";
$SISiframe_txt42 = "Klik hier om het opnieuw te proberen";

$SISiframe_txt43 = "Resolutie";
$SISiframe_txt44 = "Upload succesvol!";
$SISiframe_txt45 = "Image Link";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode Image";
$SISiframe_txt48 = "BBcode Thumb";
$SISiframe_txt49 = "Clickable Thumb";
$SISiframe_txt50 = "host nog een afbeelding";
$SISiframe_txt51 = "pad naar afbeelding niet gedefinieerd";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>
