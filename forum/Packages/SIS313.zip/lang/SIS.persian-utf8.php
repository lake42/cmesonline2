<?php
/***************************************************************************
 *			      SIS.persian-utf8.php
 *	               --------------------- 
 *	Version	      : 3.1.3
 *	Support	      : http://simpletweaks.info
 *	Translated by : Mohammad Mahdi Rostamianni - ariapedia.ir
 *  
 *      Simple Tweaks in Greek: Τσιμπήματα Απλή
 *              ©2010 Simple Tweaks
 ***************************************************************************/

// Title
$SISiframe_txt1 = "درج تصاویر";

// SISform
$SISiframe_txt2 = "فایل غیر مجاز";
$SISiframe_txt3 = "ارسال";
$SISiframe_txt4 = "لطفا تصویر مورد نظر را انتخاب کنید";
$SISiframe_txt5 = "فایل های مجاز : jpg jpeg png gif bmp tif tiff swf";
$SISiframe_txt6 = "نوع فایل انتخابی شما غیر مجاز است";
$SISiframe_txt7 = "";
// resize options for future versions
$SISiframe_txt8 = "تفییر سایز عکس?";
$SISiframe_txt9 = "100x75 (آواتار)";
$SISiframe_txt10 = "150x112 (تصویر کوچک)";
$SISiframe_txt11 = "320x240 (برای سایت یا ایمیل)";
$SISiframe_txt12 = "640x480 (برای فروم)";
$SISiframe_txt13 = "800x600 (برای مانیتور 15 اینچ)";
$SISiframe_txt14 = "1024x768 (برای مانیتور 17 اینچ)";
$SISiframe_txt15 = "1280x1024 (برای مانیتور 19 اینچ)";
$SISiframe_txt16 = "1600x1200 (برای مانیتور 21 اینچ)";
$SISiframe_txt17 = "بهینه کردن تصویر بدون تغییر سایز";
$SISiframe_txt18 = "حذف نمایش اندازه عکس از تصویر کوچک ?";
// help
$SISiframe_txt30 = "راهنمایی";
$SISiframe_txt31 = "چطور از Simple ImageShack استفاده کنیم";
$SISiframe_txt32 = "
	-روی <i>Browse</i> کلیک کنید و تصویر مورد نظر خود را انتخاب نمایید .<br />
	-روی <i>$SISiframe_txt3</i> کلیک کنید و تا ارسال کامل تصویر منتظر بمانید.<br />
	-پس از ارسال کامل تصویر ،آدرس تصویر و تصویر کوچک شده آن نمایش داده خواهد شد.<br />
	-یکی از کد های نمایش داده شده در کنار تصویر را داخل نوشته خود کپی کنید.<br />
	-در صورت تمایل برای ارسال تصویر بعدی روی <img src='./img/image_add.png' alt='' /> کلیک کنید.
			";

// SISxmlapi
$SISiframe_txt40 = "مشکلی پیش آمده است";
$SISiframe_txt41 = "مشکل در XML بازگشتی";
$SISiframe_txt42 = "برای تلاش مجدد کلیک کنید";

$SISiframe_txt43 = "ابعاد تصویر";
$SISiframe_txt44 = "تصویر ارسال شد!";
$SISiframe_txt45 = "آدرس عکس";
$SISiframe_txt46 = "BBcode";
$SISiframe_txt47 = "BBcode تصویر";
$SISiframe_txt48 = "BBcode تصویر کوچک";
$SISiframe_txt49 = "تصویر کوچک لینک شده به فایل اصلی";
$SISiframe_txt50 = "ارسال تصویر بعدی";
$SISiframe_txt51 = "لطفا تصویر مورد نظر را انتخاب کنید";


// Copyright - Don't edit please
$SISiframe_txt99 = "Powered by <a href='http://imageshack.us' target='_blank'>ImageShack.us</a><img style='vertical-align: bottom' src='./img/SISfrog.png' alt='' />";

?>
