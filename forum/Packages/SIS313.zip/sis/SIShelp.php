<?php

/***************************************************************
 *				    SIShelp.php 
 *				-------------------
 *	Version	: 3.1.0
 *	Support	: http://simpletweaks.info
 *
 *				�2010 Simple Tweaks
 ***************************************************************/

      require_once("../SSI.php");
      if (!defined('SMF'))
      die('Hacking attempt...');

	global $context, $modSettings;

	$siscolor = $modSettings['SimpleImageShack_color'];
    $sislang = $context['user']['language'];
//  check if language file exists 
    $sislangfile = "lang/SIS.$sislang.php";
    if (!file_exists($sislangfile))
    {
        $sislangfile = "lang/SIS.english.php";
    }
	include($sislangfile);

echo '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=', $context['character_set'], '" />
	<title>Simple ImageShack - powered by ImageShack (TM) - Hosting</title>
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index.css" />
	</head>
	<body>
	<div class="windowbg description">
	<H3>
';

	if ($context['allow_admin'])
		echo '<a href="http://my.imageshack.us/v_images.php" title="My ImageShack.us"><img border="0" src="./img/images.png" alt="" style="vertical-align: bottom;" /></a>';
	else
		echo '<img border="0" src="./img/images.png" alt="" style="vertical-align: bottom;" />';

echo '
			'.$SISiframe_txt31.'</H3><br />

			'.$SISiframe_txt32.'
			<br /><br />
<script type="text/javascript">
<!--
if (window.opener) document.write(\'<div style="text-align: right; font-family: Verdana;"><small><small><a href="#" onclick="self.close();"><img border="0" src="./img/close.png" height="16" width="16" alt="" title="close" /></a></small></small></div>\');
//-->
</script>

	</div>
	</body>
	</html>
	';
?>