<?php

/***************************************************************************
 *			           SISform.php
 *				---------------------
 *	Version		: 3.1.0
 *	Author		: SimpleTweaks
 *	Support		: http://simpletweaks.info
 *
 *					�2010 Simple Tweaks
 ***************************************************************************/

	require_once("../SSI.php");
	if (!defined('SMF'))
	die('Hacking attempt...');

	global $context, $settings, $modSettings;

// logged in?
	if (!$context['user']['is_logged'])
	{
		sisFormLogin();
	}
	else
	{
		sisForm();
	}



// The SISform Functions

function sisFormLogin()
{
	global $txt, $context, $settings, $modSettings;

	$siscolor = $modSettings['sis_color'];
    $sislang = $context['user']['language'];
    $sislang_file = "lang/SIS.$sislang.php";
//  check if language file exists
    if (!file_exists($sislang_file))
    {
        $sislang_file = "lang/SIS.english.php";
    }
	include_once($sislang_file);

		echo '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=', $context['character_set'], '" />
	<title>Simple ImageShack - powered by ImageShack (TM) - Hosting</title>
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index.css" />
	</head>
	<body>
		<div class="windowbg description">			
            <table border="0" width="95%" cellspacing="0" cellpadding="4">			
                  <tr>
                        <td align="center" class="largetext"><h1>'. $context['forum_name']. '</h1></td>
                  </tr>		
                  <tr>
                        <td align="center" class="description"><b>'. $SISiframe_txt1. '</b><br /><br />
                        '. $txt['login_or_register']. '<br /><br />
                        </td>
                  </tr>		
            </table>
		</div>
      </body>
</html>
		';
}

function sisForm()
{
	global $context, $settings, $modSettings;

	$siscolor = $modSettings['sis_color'];
    $sislang = $context['user']['language'];
//  check if language file exists 
    $sislang_file = "lang/SIS.$sislang.php";
    if (!file_exists($sislang_file))
    {
        $sislang_file = "lang/SIS.english.php";
    }
	include_once($sislang_file);
//	$sisload_image = "2";
	$sisload_image = $modSettings['sis_loader']; 

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Simple ImageShack - powered by ImageShack (TM) - Hosting</title>

<style type="text/css">
body, p, td {
	font-family: Verdana, Arial;
	font-size: 11px;
	color: #<?php echo $siscolor ?>;
	border-color: #bbbbbb; 
}

a {color: #<?php echo $siscolor ?>; text-decoration:none;}
a:hover {color: #<?php echo $siscolor ?>; text-decoration: underline;}
 img { border: 0px; }

textarea,input,select {
	font: 1.0em Verdana, Tahoma, Arial, Helvetica, sans-serif;
	background-color: #f9f9f9;
	border: solid 1px;
	border-color: #bbbbbb; 
	padding: 0.2em;
	margin-bottom: 0.3em;
	color: #505050;
}
</style>

<!-- <link rel="stylesheet" href="SISstyle.css" type="text/css"> -->

<script type="text/javascript">

var buttonname = '"Browse..."';

function showoptions(what) {
var ext = what.value.substr(what.value.length - 3,3).toLowerCase();
switch (ext) {
case 'jpg':
case 'peg':
case 'png':
case 'gif':
case 'bmp':
case 'tif':
case 'iff':
document.getElementById('resizeoptions').style.display='';
document.getElementById('filetypeerror').style.display='none';
document.getElementById('butan').disabled=false;
document.getElementById('butan').value='<?php echo $SISiframe_txt3 ?>';
break;
case 'swf':
document.getElementById('resizeoptions').style.display='none';
document.getElementById('filetypeerror').style.display='none';
document.getElementById('butan').disabled=false;
document.getElementById('butan').value='<?php echo $SISiframe_txt3 ?>';
break;
case '':
document.getElementById('butan').disabled=true;
document.getElementById('butan').value=buttonname;
default:
document.getElementById('resizeoptions').style.display='none';
document.getElementById('filetypeerror').style.display='';
document.getElementById('butan').disabled=true;
document.getElementById('butan').value='<?php echo $SISiframe_txt2 ?>';
break;
}
}

function openops()
{
    var o = document.getElementById('addops');
    if (o)
        o.style.display = '';
    o = document.getElementById('at1');
    if (o)
        o.style.display = 'none';
}

</script>

<script type="text/javascript">
var ray={
ajax:function(st)
	{
		this.show('load');
	},
show:function(el)
	{
		this.getID(el).style.display='';
	},
getID:function(el)
	{
		return document.getElementById(el);
	}
}
</script>
<style type="text/css">
#load{
text-align:center;
}
</style>

</head>
<body style="background-color:transparent">
<fieldset>
<legend>
<b><?php echo $SISiframe_txt1 ?></b>
</legend>
<form method="post" action="SISiframe.php" enctype="multipart/form-data" onsubmit="return ray.ajax()">

<table border="0" cellpadding="2" width="100%">
<tbody>
	<tr>
		<td style="text-align: center; vertical-align: top; width: 50%;">
      <div id="upfile" style="padding-top: 5px;">
      <?php echo $SISiframe_txt4 ?><br />
      <input name="fileupload" size="30" onchange="showoptions(this)" id="fileupload" type="file" />
      </div>
      <em><small><?php echo $SISiframe_txt5 ?></small></em>
		</td>
		<td style="text-align: center; vertical-align: top; width: 48%;">

     <div id="resizeoptions">
     </div>

      <div id="filetypeerror" style="display: none;"><p style="color: red; text-align: center; vertical-align: middle;"><?php echo $SISiframe_txt6 ?></p></div>
<!--	<input name="MAX_FILE_SIZE" value="1572864" type="hidden"> -->
	<input name="MAX_FILE_SIZE" value="5242880" type="hidden" />
      <input name="refer" value="" type="hidden" />

	<img src="./img/spacer.gif" alt="" height="7" /> 
     <p style="text-align: center"><input id="butan" style="width: 135px; cursor:pointer;" value="<?php echo $SISiframe_txt3 ?>" type="submit" /></p>

		</td>
		<td style="text-align: right; vertical-align: top;">

      <a href='javascript:void(0)' onclick="window.open('SIShelp.php','miniwin','scrollbars=1,width=300,height=300,resizable=1,toolbar=0,location=0')"><img src="./img/help.png" alt="" title="<?php echo $SISiframe_txt30 ?>" /></a>
      <noscript>
      <a href="SIShelp.php" target="_blank"><?php echo $SISiframe_txt30 ?></a>
      </noscript>

		</td>
	</tr>
</tbody>
</table>

<table border="0" cellpadding="1" width="100%">
	<tr>
		<td style="text-align: center; vertical-align: top; width: 40%;">
	<img src="./img/spacer.gif" alt="" height="18" />
		</td>

		<td style="text-align: center; vertical-align: top; width: 10%;">

<?php
if ($sisload_image != '0')
	{
echo '	<div id="load" style="display:none;"><img src="./img/sis-loader_' . $sisload_image . '.gif" alt="" /></div>';
	}
?>
		</td>

		<td style="text-align: center; vertical-align: top; width: 40%;">
	<img src="./img/spacer.gif" alt="" height="18" />
		</td>
	</tr>

	<tr>
		<td colspan="3" style="text-align: center">
      <em><small><?php echo $SISiframe_txt99 ?></small></em>
		</td>
	</tr>
</table>
</form>
</fieldset>

</body>
</html>
<?php
}
?>