<?php

/***************************************************************************
 *			           SISiframe.php
 *				---------------------
 *	Version		: 3.1.0
 *	Author		: SimpleTweaks
 *	Support		: http://simpletweaks.info
 *
 *					�2010 Simple Tweaks
 ***************************************************************************/

	require_once("../SSI.php");
	if (!defined('SMF'))
	die('Hacking attempt...');

      if ($_SERVER['REQUEST_METHOD'] == 'POST')
            include("SISxmlapi.php");
      else
      	include("SISform.php");

?>