<?php
/***************************************************************************
 *			           SISxmlapi.php
 *				---------------------
 *	Version		: 3.1.3
 *	Author		: SimpleTweaks
 *	Support		: http://simpletweaks.info
 *
 *					�2010 Simple Tweaks
 ***************************************************************************/

	require_once("../SSI.php");
	if (!defined('SMF'))
	die('Hacking attempt...');
      
      error_reporting(E_ALL); // FOR DEBUGGING

	global $context, $modSettings;
	$siscolor = $modSettings['sis_color'];
    $sislang = $context['user']['language'];
    $sislang_file = "lang/SIS.$sislang.php";
//  check if language file exists
    if (!file_exists($sislang_file))
    {
        $sislang_file = "lang/SIS.english.php";
    }
	include_once($sislang_file);

//specify either 'post' upload OR upload of a 'file' on webserver:
      $uploadType = 'post';

if($uploadType == "post"){

	/* Sample upload form to use:
		<form method="post" action="xmlapi.php" enctype="multipart/form-data">
		<input type="hidden" name="MAX_FILE_SIZE" value="1048576">
		<input type="file" name="fileupload" size="30">
		<input style="width: 100px;" type="submit" value="host it!" >
		</form>
	*/

//	if(!$_FILES['fileupload']){ exit; }
//  fix Image Path Not Set bug
	if (isset($_FILES['fileupload']['name']) && $_FILES['fileupload']['name'] != '')
	{
//  fix 'FileType error' - rename to .gif
        $ext = pathinfo($_FILES['fileupload']['name'], PATHINFO_EXTENSION);
        $ext = strtolower($ext);

        if ($ext == 'png' || $ext == 'bmp')
    	{
//            echo '<div style="text-align:center;"><small> '. $ext . ' image detected</small></div>';  
            $dest = $boarddir . '/attachments/' . $_FILES['fileupload']['name'] . '.gif';
        }
        else
        {
            $dest = $boarddir . '/attachments/' . $_FILES['fileupload']['name'];
        }

        $source = $_FILES['fileupload']['tmp_name'];

        copy($source,$dest);

// FileType error fix for latest cURL
// $xmlString = uploadToImageshack($dest, $_FILES['fileupload']['type']);
        $xmlString = uploadToImageshack($dest);

        unlink($source);
        unlink($dest);
	}
	else
	{
        echo '
    <style type="text/css">
	body, p, td {
	font-family: Verdana, Arial;
	font-size: 11px;
	color: #'.$siscolor.';
	}

	a {color: #'.$siscolor.'; text-decoration:none;}
	a:hover {color: #'.$siscolor.'; text-decoration: underline;}

	img { 
	border: 0px;
	vertical-align: bottom
	}
	</style>

	<fieldset>
	<legend>
	<b>'.$SISiframe_txt1.'</b>
	</legend>

	<table width="100%">
		<tr>
			<td style="text-align: center; vertical-align: top;">
			<center>
			<img src="./img/error.gif" alt="" /> <b>'.$SISiframe_txt40.'</b> <img src="./img/error.gif" alt="" /><br />
			<small>('.$SISiframe_txt51.')</small><br />
			<br /><a href="SISiframe.php">'.$SISiframe_txt42.'</a>
			</center>
			</td>
		</tr>
	</table>
		';
		exit;
	}

} elseif($uploadType == "file"){

//specify location of file
	$dest = '/home/image/www/creative.jpg';                       
	$xmlString = uploadToImageshack($dest);
}

// begin parsing xml data

// error or no xml returned?
    if ($xmlString == 'failed')
	{
        echo '
	<style type="text/css">
	body, p, td {
	font-family: Verdana, Arial;
	font-size: 11px;
	color: #'.$siscolor.';
	}

	a {color: #'.$siscolor.'; text-decoration:none;}
	a:hover {color: #'.$siscolor.'; text-decoration: underline;}

	img { 
	border: 0px;
	vertical-align: bottom
	}
	</style>

	<fieldset>
	<legend>
	<b>'.$SISiframe_txt1.'</b>
	</legend>

	<table width="100%">
		<tr>
			<td style="text-align: center; vertical-align: top;">
			<center>
			<img src="./img/error.gif" alt="" /> <b>'.$SISiframe_txt40.'</b> <img src="./img/error.gif" alt="" /><br />
			<small>('.$SISiframe_txt41.')</small><br />
			<br /><a href="SISform.php">'.$SISiframe_txt42.'</a>
			<br /><br /><a href="SISform2.php"><small>classic upload</small></a>
			</center>
			</td>
		</tr>
	</table>
        ';
        exit;
	}

$xmlData = explode("\n",$xmlString);

foreach($xmlData as $xmlDatum){

	$xmlDatum = trim($xmlDatum);

	if($xmlDatum != "" && !eregi("links",$xmlDatum) && !eregi("xml",$xmlDatum)){

		$xmlDatum = str_replace(">","<",$xmlDatum);
		list($xmlNull,$xmlName,$xmlValue) = explode("<",$xmlDatum);
		$xmlr[$xmlName] = $xmlValue;

	}

}

// let's display the results
echo '

	<style type="text/css">
	body, p, td {
		font-family: Verdana, Arial;
		font-size: 11px;
		border-color: #bbbbbb; 
		color: #'.$siscolor.';
	}

	a {color: #'.$siscolor.'; text-decoration:none;}
	a:hover {color: #'.$siscolor.'; text-decoration: underline;}
	img { border: 0px; }

	textarea,input,select {
		font: 1.0em Verdana, Tahoma, Arial, Helvetica, sans-serif;
		background-color: #f9f9f9;
		border: solid 1px;
		border-color: #bbbbbb; 
		padding: 0.2em;
		margin-bottom: 0.3em;
	}

	input:hover {
	    border: 1px solid #FF9933;
	}
</style>

	<fieldset>
	<legend>
	<b>'.$SISiframe_txt1.'</b>
	</legend>

<table border="0" cellpadding="2" width="100%">
<tbody>
	<tr>
';

// fix $xmlr["thumb_exists"] always yes
$sis_image_thumb = 'no';
$sis_image_res = $xmlr["resolution"];
$token = strtok($sis_image_res, "x");
while ($token != false)
  {
    if ($token > 200)
    $sis_image_thumb = 'yes';
    $token = strtok(" ");
  }
// fix $xmlr["thumb_exists"] always yes

// if ($xmlr["thumb_exists"] == 'no')
if ($sis_image_thumb == 'no')
	{
	echo '
		<td style="text-align: left; vertical-align: top; width: 30%;">
		<a href="'.$xmlr["image_link"].'" target="_blank"><img src="'.$xmlr["image_link"].'" border="0" /></a>
		<br />
		<small>'.$SISiframe_txt43.': '.$xmlr["resolution"].'</small>
		</td>

		<td style="text-align: left; vertical-align: top; width: 65%;">
		<p style="color: #4E9258;"><b>'.$SISiframe_txt44.'</b></p>
        ';
		if (!empty($modSettings['sis_imagelink']))
		{
		echo '
		  '.$SISiframe_txt45.':<br />
		  <input type="text" size="60" value="'.$xmlr["image_link"].'" onFocus="this.select()" /><br />
		';
        }
		if (!empty($modSettings['sis_imagelink_bbcode']))
		{
		echo '
		  '.$SISiframe_txt46.':<br />
		  <input type="text" size="60" value="[img]'.$xmlr["image_link"].'[/img]" onFocus="this.select()" /><br />
		';
        }
		echo '
		</td>
		';
	}
// elseif ($xmlr["thumb_exists"] == 'yes')
elseif ($sis_image_thumb == 'yes')
	{
	echo '
		<td style="text-align: left; vertical-align: top; width: 30%;">
		<a href="'.$xmlr["image_link"].'" target="_blank"><img src="'.$xmlr["thumb_link"].'" border="0" /></a>
		<br />
		<small>'.$SISiframe_txt43.': '.$xmlr["resolution"].'</small>
		</td>

		<td style="text-align: left; vertical-align: top; width: 65%;">
		<p style="color: #4E9258;"><b>'.$SISiframe_txt44.'</b></p>
        ';
		if (!empty($modSettings['sis_imagelink']))
		{
		echo '
		  '.$SISiframe_txt45.':<br />
		  <input type="text" size="60" value="'.$xmlr["image_link"].'" onFocus="this.select()" /><br />
		';
        }
		if (!empty($modSettings['sis_imagelink_bbcode']))
		{
		echo '
		  '.$SISiframe_txt47.':<br />
		  <input type="text" size="60" value="[img]'.$xmlr["image_link"].'[/img]" onFocus="this.select()" /><br />
		';
        }
		if (!empty($modSettings['sis_thumblink_bbcode']))
		{
		echo '
		  '.$SISiframe_txt48.':<br />
		  <input type="text" size="60" value="[img]'.$xmlr["thumb_link"].'[/img]" onFocus="this.select()" /><br />
		';
        }
		if (!empty($modSettings['sis_thumblink_click']))
		{
		echo '
		  '.$SISiframe_txt49.':<br />
		  <input type="text" size="60" value="[url='.$xmlr["image_link"].'][img]'.$xmlr["thumb_link"].'[/img][/url]" onFocus="this.select()" /><br />
		';
        }
		echo '
		</td>
		';
	}

	echo '
		<td style="text-align: right; vertical-align: top; width: 5%;">
			<a href="SISform.php"><img src="./img/image_add.png" alt="" title="'.$SISiframe_txt50.'" /></a>
		</td>
		<td style="text-align: right; vertical-align: top; width: 5%;">
			<a href="javascript:void(0)" onclick="window.open(\'SIShelp.php\',\'miniwin\',\'scrollbars=1,width=300,height=300,resizable=1,toolbar=0,location=0\')"><img src="./img/help.png" alt="" title="'.$SISiframe_txt30.'"</a>
			<noscript>
			<a href="SIShelp.php" target="_blank">'.$SISiframe_txt30.'</a>
			</noscript>
		</td>
	</tr>
</tbody>
</table>
		</fieldset>
	';


//two functions, one for uploading from from file, the other for uploading from url, editing below this line advised only to those who know what they are doing :)

// FileType error fix for latest cURL
//        function uploadToImageshack($filename, $sFileType) {
        function uploadToImageshack($filename) {
		$ch = curl_init("http://www.imageshack.us/index.php");

		global $modSettings, $context;


		$sistags = $modSettings['sis_tags'];
		$siscookie = $modSettings['sis_cookie'];

		if (!empty($modSettings['sis_rembar']))
		{
			$sisrembar = $modSettings['sis_rembar'];
			$post['rembar']=$sisrembar;
		}

		if (!empty($modSettings['sis_forumtag']))
		{
                  $sisUsertag = $context['forum_name'].'+user='.$context['user']['name'].'+id='.$context['user']['id'];
		}
            else
            {
                  $sisUsertag = '';                  
            }
		$post['tags']=$sistags.','.$sisUsertag;
		$post['cookie']=$siscookie;
		$post['xml']='yes';
		$post['fileupload']='@'.$filename;

// FileType error fix for latest cURL
//        $post['fileupload']='@'.$filename.";type=".$sFileType;

    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $ext = strtolower($ext);
    if ($ext == 'png' || $ext == 'bmp')
	{
    echo '<div style="text-align:center;"><small> '. $ext . ' image detected - please rename to .gif and try again</small></div>';  
    }

                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 240);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect: '));

                $result = curl_exec($ch);
                curl_close($ch);

// display xml for debugging
// echo $result;

                if (strpos($result, '<'.'?xml version="1.0" encoding="iso-8859-1"?>') === false)
                {
                    echo '<div style="text-align:center;"><small>' . $result . '</small></div>';                    
                    return 'failed';
                }
                else
                {
                    return $result; // XML data
                }
        }

        function uploadURLToImageshack($url) {
                $ch = curl_init("http://www.imageshack.us/transload.php");

                $post['xml']='yes';
                $post['url']=$url;

                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect: '));

                $result = curl_exec($ch);
                curl_close($ch);

                if (strpos($result, '<'.'?xml version="1.0" encoding="iso-8859-1"?>') === false) {
                        return 'failed';
                } else {
                        return $result; // XML data
                }
        }
?>