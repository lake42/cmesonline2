[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Anti-Bot: Are You Human/Bot?[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=1]Lean[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.1[/b][/i]
Created by Karl Benson[/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Are you Human is dedicated to the safety modification of our forum and spam bots with this registration we ask whether human or a bot.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Are You Human es una modificacion dedicada a la seguridad de nuestro foro y los bots de spam, con esto obtenemos en el registro que pregunte si es humano o un bot.[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Question Are You human/ Are You Bot[/li]
	[li]Order Answer[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Pregunta si eres humano o eres bot[/li]
	[li]Ordena Preguntas[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center][img]http://i.imgur.com/khuCz.png[/img][/center]

[center][img]http://i.imgur.com/NNmPd.png[/img][/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8
- Portuguese_pt
- Portuguese_brazilian
- German[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Anti-Bot: Are You Human/Bot?[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]