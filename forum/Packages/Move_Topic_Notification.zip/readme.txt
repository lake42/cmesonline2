[center][color=blue][size=16px][color=green]Move Topic Notification v1.2 - Developed by NIBOGO - Created by Valodim
[/color][/size][/color][color=green]Will add an option to the move topic dialogue to notify the original poster of the thread via PM.[/color][/center]
[hr]
[center][url=http://www.simplemachines.org/community/index.php?topic=158934.0][b]Support topic[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?mod=708][b]Link to Mod[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=search;author=126412][b]My Mods[/b][/url] | [url=http://www.smfpacks.com][b]Website[/b][/url]
[/center]
[hr]
[b]
Author[/b]:
- NIBOGO

[b]Features[/b]:
o Notify the author of his topic has been moved by PM.
o The PM Notification option does not show up for own topics, or topics posted by guests!
o Simple and friendly interface to set the PM Body.
o Easy to use commands like {topic}, {prev_board}, {subject} and {board}.

[b]Manual Edit:[/b]
Try to use the parser:

[url=http://custom.simplemachines.org/mods/index.php?action=parse;mod=708;attach=103214;smf_version=1.1.9]SMF 1.1.X Parser[/url]

[url=http://custom.simplemachines.org/mods/index.php?action=parse;mod=708;attach=103214;smf_version=2.0_RC1-1]SMF 2.0 Parser[/url]

[b]Languages[/b]:
- English/English-utf8
- Spanish_es/Spanish_latin - Spanish_es-utf8/Spanish_latin-utf8
- Portuguse_pt/Portuguese_brazilian/Portuguese_pt-utf8/Portuguese_brazilian-utf8 by Sakae
- Turkish/Turkish-utf8 by Daydreamer
- Greek/Greek-utf8
- Russian/Russian-utf8 by Bugo

[b]Compatibility[/b]:
o SMF 2.0 RC3
o SMF 2.0 RC2
o SMF 1.1.X

[b]Special Thanks[/b]:
- [url=http://www.simplemachines.org/community/index.php?action=profile;u=5346]Valodim[/url]: Original author of the mod and the idea. 
- sayfam: He translate the mod to turkish/turkish-utf8

[size=16px]Changelog:[/size]
[b]1.2 - 08 Mar 2010[/b]
o Added support for SMF 2.0 RC3
o Replaced commands now you can use {topic}, {prev_board}, {subject} and {board}.
o Added explanation of each command in the Move Topic Page.
o Mod renamed to "Move Topic Notification"

[b]1.1.3 - 22 Nov 2009[/b]
o Added support for SMF 2.0 RC2
o Fixed issue sending the PM caused for an error in the installation.

[b]1.1.2 - 08 Oct 2009[/b]
o Added support for SMF 1.1.10

[b]1.1 - 23 June 2009[/b]
o Fixed a big bug on SMF 2.0 RC1 & SMF 2.0 RC1-1. Please upgrade (Uninstall the last version and install this one)
o Changed the strings in Turkish and Portuguese
o Fixed a little bug in the installation with the greek language

[b]1.0 - 18 June 2009[/b]
o Now mod developed by NIBOGO
o Changed all the strings to Modifications.{language}.php
o Added Support for SMF 2.0 RC1-1 & SMF 1.1.9 and below versions
o Added Spanish/Spanish-UTF8, Spanish Latin/Spanish Latin-UTF8, Spanish Es/ Spanish Es-UTF8, Greek-UTF8, Portuguese, English-UTF8 and Turkish-UTF8

[b]0.901[/b]
o Mod created by [url=http://www.simplemachines.org/community/index.php?action=profile;u=5346]Valodim[/url]
o No PM notify if topic starter is guest, added turkish language strings, and moved to xml mod format